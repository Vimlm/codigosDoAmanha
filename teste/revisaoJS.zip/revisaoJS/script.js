// let nome = 'Victor';
// let sobrenome = "Martins";
// let nomeCompleto = `${nome} ${sobrenome}`;
// let numero = 10;
// let numeroString = '20';
// let numero20 = +numeroString;
// let possuiCurso = true; //false

// let somaNumeroString = nome + numero;

//condicionais
// if(numero < 10) {
//   console.log('O numéro é menor a 10');
// } else if (numero >= 10) {
//   console.log('O numéro é maior que ou igual 10.');
// } else {
//   console.log('O numéro é maior 10.');
// }

// if
// if else 
// if elseif elseif... 
// if elseif else

// loos de repetição ~ while, for, foreach
// console.log('1');
// console.log('2');
// console.log('3');
// console.log('4');
// console.log('5');

//condição, inicializador, incremento
// let n = 1;

// while (n <= 5) {
//   console.log('n = ' + n);
//   n++;
// }

// for(let i = 1; i <= 5; i++) {
//   console.log('i = ' + i);
// }

//funções - reaproveitar códigos;
//2 etapas ~ Criação, Chamada

//Tipos de função
//Função com parâmetro e sem retorno
//Função com parâmetro e com retorno
//Função sem parâmetro e com retorno
//Função sem parâmetro e sem retorno

//Criação
// function somaNumero(x, y) {
//   console.log(x + y);
// }

// function subtraiNumero(z, w) {
//   return z - w;
// }

// function sobreNome() {
//   return 'Martins';
// }

// function nome() {
//   console.log('Victor');
// }

// function podeDirgir(idade) {
//   if(idade >= 18) {
//     return 'Pode Dirigir';
//   } else {
//     return 'Não pode dirigir';
//   }
// }

// console.log(podeDirgir(15));

// let minhaIdade = 17;
// console.log(podeDirgir(minhaIdade));

//Chamando a função
// somaNumero(4, 2);
// somaNumero(15, 3);

// let resultado = subtraiNumero(10, 5);
